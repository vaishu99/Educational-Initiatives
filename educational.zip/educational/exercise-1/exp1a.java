import java.util.ArrayList;
import java.util.List;

// Observer interface
interface Observer {
    void update(float temperature, float humidity);
}

// Subject (WeatherStation) class
class WeatherStation {
    private List<Observer> observers = new ArrayList<>();
    private float temperature;
    private float humidity;

    public void addObserver(Observer o) {
        observers.add(o);
    }

    public void removeObserver(Observer o) {
        observers.remove(o);
    }

    public void setMeasurements(float temperature, float humidity) {
        this.temperature = temperature;
        this.humidity = humidity;
        notifyObservers();
    }

    private void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(temperature, humidity);
        }
    }
}

// Display (Observer) class
class PhoneDisplay implements Observer {
    private String displayName;

    public PhoneDisplay(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public void update(float temperature, float humidity) {
        System.out.println(displayName + " updated: Temp = " + temperature + ", Humidity = " + humidity);
    }
}

public class ObserverPatternDemo {
    public static void main(String[] args) {
        WeatherStation weatherStation = new WeatherStation();

        Observer phoneDisplay1 = new PhoneDisplay("Phone Display 1");
        Observer phoneDisplay2 = new PhoneDisplay("Phone Display 2");

        weatherStation.addObserver(phoneDisplay1);
        weatherStation.addObserver(phoneDisplay2);

        weatherStation.setMeasurements(22.5f, 70.0f); // Both displays will be notified of this update
        weatherStation.setMeasurements(23.0f, 65.0f); // Both displays will be notified again
    }
}
