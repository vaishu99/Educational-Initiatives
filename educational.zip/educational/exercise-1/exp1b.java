// Strategy interface
interface DiscountStrategy {
    double applyDiscount(double amount);
}

// Concrete strategy 1: Percentage discount
class PercentageDiscount implements DiscountStrategy {
    private double percentage;

    public PercentageDiscount(double percentage) {
        this.percentage = percentage;
    }

    @Override
    public double applyDiscount(double amount) {
        return amount - (amount * (percentage / 100));
    }
}

// Concrete strategy 2: Fixed amount discount
class FixedAmountDiscount implements DiscountStrategy {
    private double discount;

    public FixedAmountDiscount(double discount) {
        this.discount = discount;
    }

    @Override
    public double applyDiscount(double amount) {
        return amount - discount;
    }
}

// Context class: Shopping Cart
class ShoppingCart {
    private DiscountStrategy discountStrategy;

    public void setDiscountStrategy(DiscountStrategy discountStrategy) {
        this.discountStrategy = discountStrategy;
    }

    public double checkout(double amount) {
        return discountStrategy.applyDiscount(amount);
    }
}

public class StrategyPatternDemo {
    public static void main(String[] args) {
        ShoppingCart cart = new ShoppingCart();

        // Apply 10% discount
        cart.setDiscountStrategy(new PercentageDiscount(10));
        System.out.println("Final price after percentage discount: " + cart.checkout(100)); // Outputs: 90.0

        // Apply fixed discount of $20
        cart.setDiscountStrategy(new FixedAmountDiscount(20));
        System.out.println("Final price after fixed discount: " + cart.checkout(100)); // Outputs: 80.0
    }
}
