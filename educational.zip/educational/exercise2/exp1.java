// Abstract class representing a generic smart device (Abstraction)
abstract class SmartDevice {
    // Encapsulating attributes (private)
    private int id;
    private String deviceType;
    private String status;

    // Constructor
    public SmartDevice(int id, String deviceType) {
        this.id = id;
        this.deviceType = deviceType;
        this.status = "off";  // Default status is off
    }

    // Abstract methods (must be implemented by subclasses)
    public abstract void turnOn();
    public abstract void turnOff();

    // Getter for device status (encapsulation)
    public String getStatus() {
        return deviceType + " " + id + " is " + status + ".";
    }

    // Protected method to set status (for subclasses to use)
    protected void setStatus(String status) {
        this.status = status;
    }
}

// Light class inheriting from SmartDevice (Inheritance)
class Light extends SmartDevice {
    public Light(int id) {
        super(id, "Light");  // Calling superclass constructor
    }

    @Override
    public void turnOn() {
        setStatus("on");
    }

    @Override
    public void turnOff() {
        setStatus("off");
    }
}

// Thermostat class inheriting from SmartDevice (Inheritance)
class Thermostat extends SmartDevice {
    private int temperature;  // Additional attribute specific to Thermostat

    public Thermostat(int id, int temperature) {
        super(id, "Thermostat");
        this.temperature = temperature;
    }

    public void setTemperature(int temperature) {
        this.temperature = temperature;
        System.out.println("Thermostat " + temperature + " set to " + temperature + " degrees.");
    }

    @Override
    public void turnOn() {
        setStatus("on");
    }

    @Override
    public void turnOff() {
        setStatus("off");
    }

    @Override
    public String getStatus() {
        return super.getStatus() + " Set to " + temperature + " degrees.";
    }
}

// DoorLock class inheriting from SmartDevice (Inheritance)
class DoorLock extends SmartDevice {
    public DoorLock(int id) {
        super(id, "Door");
    }

    public void lock() {
        setStatus("locked");
    }

    public void unlock() {
        setStatus("unlocked");
    }

    @Override
    public void turnOn() {
        lock();  // In this case, turnOn means lock the door
    }

    @Override
    public void turnOff() {
        unlock();  // In this case, turnOff means unlock the door
    }
}

// SmartHomeSystem class to manage the devices (Polymorphism)
class SmartHomeSystem {
    private List<SmartDevice> devices = new ArrayList<>();

    // Add a new device
    public void addDevice(SmartDevice device) {
        devices.add(device);
    }

    // Remove a device by ID
    public void removeDevice(int id) {
        devices.removeIf(device -> device.getId() == id);
    }

    // Turn on a specific device by ID
    public void turnOnDevice(int id) {
        for (SmartDevice device : devices) {
            if (device.getId() == id) {
                device.turnOn();
            }
        }
    }

    // Turn off a specific device by ID
    public void turnOffDevice(int id) {
        for (SmartDevice device : devices) {
            if (device.getId() == id) {
                device.turnOff();
            }
        }
    }

    // Get the status of all devices
    public void getStatus() {
        for (SmartDevice device : devices) {
            System.out.println(device.getStatus());
        }
    }
}

// Main class to run the simulation
public class SmartHomeSimulation {
    public static void main(String[] args) {
        SmartHomeSystem homeSystem = new SmartHomeSystem();

        // Creating devices
        SmartDevice light = new Light(1);
        SmartDevice thermostat = new Thermostat(2, 70);
        SmartDevice doorLock = new DoorLock(3);

        // Adding devices to the system
        homeSystem.addDevice(light);
        homeSystem.addDevice(thermostat);
        homeSystem.addDevice(doorLock);

        // Display the initial status of all devices
        homeSystem.getStatus();

        // Turning devices on/off
        homeSystem.turnOnDevice(1);  // Turn on light
        homeSystem.turnOffDevice(3);  // Unlock door

        // Display the updated status of all devices
        homeSystem.getStatus();

        // Set thermostat temperature
        ((Thermostat) thermostat).setTemperature(75);  // Polymorphism in action

        // Display the final status of all devices
        homeSystem.getStatus();
    }
}
