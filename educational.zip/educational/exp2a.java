// Product interface
interface Vehicle {
    void drive();
}

// Concrete product 1: Car
class Car implements Vehicle {
    @Override
    public void drive() {
        System.out.println("Driving a car");
    }
}

// Concrete product 2: Truck
class Truck implements Vehicle {
    @Override
    public void drive() {
        System.out.println("Driving a truck");
    }
}

// Concrete product 3: Motorcycle
class Motorcycle implements Vehicle {
    @Override
    public void drive() {
        System.out.println("Riding a motorcycle");
    }
}

// Creator class: VehicleFactory
class VehicleFactory {
    // Factory method
    public Vehicle createVehicle(String vehicleType) {
        if (vehicleType == null) {
            return null;
        }
        switch (vehicleType.toLowerCase()) {
            case "car":
                return new Car();
            case "truck":
                return new Truck();
            case "motorcycle":
                return new Motorcycle();
            default:
                return null;
        }
    }
}

public class FactoryMethodDemo {
    public static void main(String[] args) {
        VehicleFactory factory = new VehicleFactory();

        // Create a Car
        Vehicle vehicle1 = factory.createVehicle("car");
        vehicle1.drive(); // Output: Driving a car

        // Create a Truck
        Vehicle vehicle2 = factory.createVehicle("truck");
        vehicle2.drive(); // Output: Driving a truck

        // Create a Motorcycle
        Vehicle vehicle3 = factory.createVehicle("motorcycle");
        vehicle3.drive(); // Output: Riding a motorcycle
    }
}
