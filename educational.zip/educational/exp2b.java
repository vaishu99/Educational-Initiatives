// Singleton Logger class
class Logger {
    // Private static instance of Logger (single instance)
    private static Logger loggerInstance;

    // Private constructor to prevent instantiation
    private Logger() {}

    // Public method to get the single instance of Logger
    public static Logger getInstance() {
        if (loggerInstance == null) {
            loggerInstance = new Logger();
        }
        return loggerInstance;
    }

    // Method to log a message
    public void log(String message) {
        System.out.println("Log entry: " + message);
    }
}

public class SingletonPatternDemo {
    public static void main(String[] args) {
        // Attempt to create multiple instances of Logger
        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();

        // Log some messages
        logger1.log("This is the first log message.");
        logger2.log("This is the second log message.");

        // Verify that both logger1 and logger2 refer to the same instance
        System.out.println("logger1 and logger2 are the same instance: " + (logger1 == logger2)); // Output: true
    }
}
