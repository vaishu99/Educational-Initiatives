// Existing interface for bank payments
interface BankPayment {
    void makePayment(double amount);
}

// Concrete implementation of bank payment
class BankPaymentService implements BankPayment {
    @Override
    public void makePayment(double amount) {
        System.out.println("Processing bank payment of $" + amount);
    }
}

// PayPal API (Third-party system with a different interface)
class PayPal {
    public void sendPayment(double amount) {
        System.out.println("Processing PayPal payment of $" + amount);
    }
}

// Adapter to integrate PayPal with BankPayment
class PayPalAdapter implements BankPayment {
    private PayPal payPal;

    public PayPalAdapter(PayPal payPal) {
        this.payPal = payPal;
    }

    @Override
    public void makePayment(double amount) {
        // Adapt PayPal's sendPayment method to fit the BankPayment interface
        payPal.sendPayment(amount);
    }
}

public class AdapterPatternDemo {
    public static void main(String[] args) {
        // Use BankPayment service directly
        BankPayment bankPayment = new BankPaymentService();
        bankPayment.makePayment(100); // Output: Processing bank payment of $100

        // Use PayPal via the adapter
        PayPal payPal = new PayPal();
        BankPayment paypalPayment = new PayPalAdapter(payPal);
        paypalPayment.makePayment(200); // Output: Processing PayPal payment of $200
    }
}
